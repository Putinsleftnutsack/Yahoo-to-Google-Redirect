// background.js
chrome.runtime.onInstalled.addListener(() => {
  console.log("Yahoo to Google Redirect extension installed.");
});
